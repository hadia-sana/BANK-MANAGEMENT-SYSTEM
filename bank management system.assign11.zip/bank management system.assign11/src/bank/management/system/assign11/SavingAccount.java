/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bank.management.system.assign11;

import java.io.Serializable;
import javax.swing.JOptionPane;

/**
 *
 * @author Hp
 */
public class SavingAccount extends account implements Serializable {
    private int trans_limit;
    private int interest;
    private int trans;
    private int min_bal;
    


    public SavingAccount(int trans_limit, int intersest, int trans, int min_bal, String accountNumb, String accountName, String accountType, int bal) {
        super(accountNumb, accountName, accountType, bal);
        this.trans_limit = trans_limit;
        this.interest = intersest;
        this.trans = trans;
        this.min_bal = min_bal;
    }

    public SavingAccount() {
    }

    public SavingAccount(int trans_limit, int intersest, int trans, int min_bal) {
        this.trans_limit = trans_limit;
        this.interest = intersest;
        this.trans = trans;
        this.min_bal = min_bal;
    }

    public int getTrans_limit() {
        return trans_limit;
    }

    public void setTrans_limit(int trans_limit) {
        this.trans_limit = trans_limit;
    }

    public int getInterest() {
        return interest;
    }

    public void setInterest(int intersest) {
        this.interest = intersest;
    }

    public int getTrans() {
        return trans;
    }

    public void setTrans(int trans) {
        this.trans = trans;
    }

    public int getMin_bal() {
        return min_bal;
    }

    public void setMin_bal(int min_bal) {
        this.min_bal = min_bal;
    }
    public void addinterest(){
    int inter=bal*interest;
    bal+=inter;
    
    }
    public int withdraws(int amount){
    if(trans<trans_limit){
    if((bal-amount)>min_bal){
    super.withdraw(amount);
    return 1;
    }
    else{
    JOptionPane.showMessageDialog(null,"insufficient min balance");
    return 0;
    }
    }
    else{
    JOptionPane.showMessageDialog(null,"you have reached the transaction limit");
    return 0;
    }
   
    }
}
