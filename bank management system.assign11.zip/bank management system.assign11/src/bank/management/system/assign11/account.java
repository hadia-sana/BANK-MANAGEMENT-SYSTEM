/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bank.management.system.assign11;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Hp
 */
public class account implements Serializable{
    protected String accountNumb;
     protected String accountName;
     protected String accountType;
     protected int bal;
     protected static File f;
     private static ArrayList<account>acc=new ArrayList();
     
    static{
     f=new File("bankaccount.java");
    }
    public static File getf(){
    return f;
    }
    public String getAccountNumb() {
        return accountNumb;
    }

    public void setAccountNumb(String accountNumb) {
        this.accountNumb = accountNumb;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public int getBal() {
        return bal;
    }

    public void setBal(int bal) {
        this.bal = bal;
    }

    public account(String accountNumb, String accountName, String accountType, int bal) {
        this.accountNumb = accountNumb;
        this.accountName = accountName;
        this.accountType = accountType;
        this.bal = bal;
       // this.f=new File("bankaccount.java");
    }

    public account() {
        // this.f=new File("bankaccount.java");
    }
     public void deposit(int amount){
     bal+=amount;
     JOptionPane.showMessageDialog(null,"successfully deposited");
     }
     public void withdraw(int amount){
     if(bal>0 && amount<bal){
     bal-=amount;
     JOptionPane.showMessageDialog(null,"successfully withdrawed");
     }
     else{
     JOptionPane.showMessageDialog(null,"insufficient balance");
     }
     }
     public static void deleteacc(String a){
     for(account aa:acc){
     if(aa.getAccountNumb().equals(a)){
     acc.remove(aa);
     break;
     }
     
     }
     ObjectOutputStream out=null;
                    try {
                    out=new ObjectOutputStream (new FileOutputStream (f));
                    for(account aa:acc){
                    out.writeObject(aa);}
                    out.flush();
                    out.close();
                    } catch (IOException ex) {
                    System.out.print("not saved");
                    }
     
     }
      public static void filewrite(account a){
         acc.add(a);
                    ObjectOutputStream out=null;
                    try {
                    out=new ObjectOutputStream (new FileOutputStream (f));
                    for(account aa:acc){
                    out.writeObject(aa);}
                    out.flush();
                    out.close();
                    } catch (IOException ex) {
                    System.out.print("not saved");
                    }
                    
                  
     
     }

    
}
