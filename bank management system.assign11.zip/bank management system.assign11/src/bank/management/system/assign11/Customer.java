/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bank.management.system.assign11;

/**
 *
 * @author Hp
 */
public class Customer {
    private String name;
    private String id;
    private account acc;

    public Customer() {
    }

    public Customer(String name, String id, account acc) {
        this.name = name;
        this.id = id;
        this.acc = acc;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public account getAcc() {
        return acc;
    }

    public void setAcc(account acc) {
        this.acc = acc;
    }
}
